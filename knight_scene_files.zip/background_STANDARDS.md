# Dawn Valley background - standards and techniques used

All of these are in `bg_valley.py` (the script that generated every image). Each one is a real, widely used
convention in game art or procedural generation.

## Resolution, format and colour
1. **320x180 internal resolution (16:9)** - integer-scales to 1280x720 (x4), 1920x1080 (x6) and 4K (x12) with no blurry pixels.
   Your GDevelop project is 1280x720 with a camera zoom of 4, so one screen is exactly 320x180.
2. **Fixed public palette: Sweetie 16 (by GrafxKid)** - every pixel is one of 16 colours, which keeps the whole art set consistent.
3. **sRGB colour space with linear-light blending (IEC 61966-2-1 transfer functions)** - fog and lighting are mixed in linear light, then converted back to sRGB.
4. **CIE 1976 L*a*b* (D65) perceptual distance** - used to match each colour to the nearest palette colour.
5. **PNG (ISO/IEC 15948), 8-bit RGBA, straight (non-premultiplied) alpha, lossless**, with nearest-neighbour scaling (no smoothing).

## Procedural generation
6. **Perlin gradient noise with the improved quintic fade (6t^5 - 15t^4 + 10t^3)** - the base random function.
7. **Fractional Brownian motion (fBm)** - 5 octaves, lacunarity 2, gain 0.5.
8. **Ridged multifractal noise (Musgrave)** - gives sharp mountain peaks.
9. **Periodic noise lattice** - the noise wraps at the image width, so every layer tiles seamlessly left-to-right for scrolling.
10. **Poisson-disc style minimum-distance sampling (dart-throwing variant)** - spaces the pine trees naturally with no clumping or grid look.

## Lighting and depth
11. **Lambertian diffuse shading (N.L)** - mountain and hill faces are lit from the slope of the ridge line.
12. **One consistent key-light direction (upper right)** - used for the mountains, hills, ruins, trees and the sun.
13. **Exponential atmospheric perspective (Beer-Lambert / exponential fog, f = 1 - e^(-k*d))** - far layers are hazier and lighter than near layers.
14. **Value hierarchy** - lightest and lowest contrast in the distance, darkest and strongest contrast in the foreground, so the playable area stays readable.
15. **Rule of thirds composition** - the ruined fortress sits on the left third and the sun on the right third.

## Pixel-art and game-engine practice
16. **Ordered dithering with an 8x8 Bayer matrix (Bayer, 1973)** - fakes smooth gradients while staying inside the palette.
17. **Parallax layering** - six separate layers (sky, far mountains, mid mountains, foothills and ruins, mist, foreground) for depth.
18. **Layer naming convention** - `layer_<order>_<name>.png`, drawn back to front.

## Suggested parallax speeds (fraction of camera speed)
sky 0.00, far mountains 0.10, mid mountains 0.25, foothills + ruins 0.45, mist 0.65, foreground 1.00
