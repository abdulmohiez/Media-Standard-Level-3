import os
import numpy as np
from PIL import Image, ImageDraw

W, H = 28, 14
OUT = (17, 19, 24, 255)
st_hi, st, st_sh = (209, 216, 224, 255), (136, 149, 167, 255), (75, 85, 99, 255)
gold, gold_hi = (241, 196, 15, 255), (255, 232, 130, 255)
wood, wood_hi, wood_sh = (110, 70, 44, 255), (156, 104, 62, 255), (70, 44, 34, 255)
blue, blue_hi = (47, 90, 168, 255), (130, 176, 245, 255)

def gun(dx=0, flash=False):
    im = Image.new('RGBA', (W, H), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    R = lambda x0, y0, x1, y1, c: d.rectangle([x0 + dx, y0, x1 + dx, y1], fill=c)
    P = lambda x, y, c: d.point((x + dx, y), fill=c)
    # stock
    R(1, 5, 6, 8, wood); R(1, 5, 6, 5, wood_hi); R(2, 8, 6, 8, wood_sh); R(1, 5, 1, 7, gold)
    d.point((1 + dx, 8), fill=(0, 0, 0, 0))
    # grip
    d.polygon([(5 + dx, 9), (8 + dx, 9), (7 + dx, 12), (4 + dx, 12)], fill=wood)
    R(5, 9, 5, 11, wood_hi); P(6, 11, gold)
    # hammer
    P(6, 3, st); P(7, 3, st); P(7, 4, st)
    # receiver, inlay, gem
    R(6, 4, 11, 8, st); R(6, 4, 11, 4, st_hi); R(6, 8, 11, 8, st_sh)
    R(7, 7, 10, 7, gold)
    R(8, 5, 9, 6, blue); P(8, 5, blue_hi)
    # barrel, bands, muzzle, sight
    R(11, 5, 19, 7, st); R(11, 5, 19, 5, st_hi); R(11, 7, 19, 7, st_sh)
    R(14, 5, 14, 7, gold); R(17, 5, 17, 7, gold)
    R(19, 4, 20, 8, gold); R(19, 4, 20, 4, gold_hi)
    P(18, 4, st_hi)
    # trigger guard + trigger
    for x, y in ((9, 9), (10, 10), (11, 10), (12, 9)): P(x, y, gold)
    P(10, 9, st_sh)
    # outline
    a = np.array(im)[:, :, 3] > 0
    dil = a.copy(); dil[1:] |= a[:-1]; dil[:-1] |= a[1:]; dil[:, 1:] |= a[:, :-1]; dil[:, :-1] |= a[:, 1:]
    arr = np.array(im); arr[dil & ~a] = OUT; im = Image.fromarray(arr)
    if flash:
        for x, y, c in [(22, 6, (255, 255, 235, 255)), (23, 6, (255, 255, 235, 255)), (22, 5, (255, 255, 235, 255)), (22, 7, (255, 255, 235, 255)),
                        (24, 6, (255, 214, 60, 255)), (25, 6, (255, 170, 40, 255)), (23, 5, (255, 214, 60, 255)), (23, 7, (255, 214, 60, 255)),
                        (22, 3, (255, 214, 60, 255)), (23, 4, (255, 170, 40, 255)), (22, 9, (255, 214, 60, 255)), (23, 8, (255, 170, 40, 255))]:
            im.putpixel((x + dx, y), c)
    return im

out = '/mnt/user-data/outputs/gun_sprite'; os.makedirs(out, exist_ok=True)
frames = {'Gun_1': gun(), 'Gun_Fire_1': gun(-1, True), 'Gun_Fire_2': gun(-1)}
for n, f in frames.items(): f.save(f'{out}/{n}.png')

# preview: gun alone (12x) and held by the knight (8x), pivot at his shoulder
sky = (150, 196, 222, 255)
Z = 12; row = Image.new('RGBA', (W * Z * 3 + 40, H * Z), sky)
for i, f in enumerate(frames.values()): row.alpha_composite(f.resize((W * Z, H * Z), Image.NEAREST), (i * (W * Z + 20), 0))
knight = Image.open('/mnt/user-data/outputs/knight_frames_gun/Knight_Idle_1.png')
scene = Image.new('RGBA', (32, 32), (0, 0, 0, 0)); scene.alpha_composite(knight)
scene.alpha_composite(frames['Gun_1'], (17 - 6, 13 - 6))
Z2 = 12; held = Image.new('RGBA', (32 * Z2, 32 * Z2), sky); held.alpha_composite(scene.resize((32 * Z2, 32 * Z2), Image.NEAREST))
canvas = Image.new('RGBA', (max(row.width, held.width), row.height + held.height + 20), sky)
canvas.alpha_composite(row, (0, 0)); canvas.alpha_composite(held, (0, row.height + 20))
canvas.convert('RGB').save('/mnt/user-data/outputs/gun_preview.png')
print('ok')
