import math, numpy as np, trimesh
from PIL import Image, ImageDraw

OUTC = np.array([17, 19, 24])
BASE = '/mnt/user-data/outputs'
SCENE = BASE + '/knight_scene'

def solid_mask(path):
    a = np.array(Image.open(path).convert('RGBA'))
    return (a[:, :, 3] > 0) & ~np.all(a[:, :, :3] == OUTC, axis=2), a[:, :, :3]

def erode(m, n):
    for _ in range(n):
        e = m.copy(); e[1:] &= m[:-1]; e[:-1] &= m[1:]; e[:, 1:] &= m[:, :-1]; e[:, :-1] &= m[:, 1:]
        e[0] = e[-1] = False; e[:, 0] = e[:, -1] = False; m = e
    return m

def extrude(path, depth, zoff=0, offx=0, offy=0, feet=27, cx=16):
    m, rgb = solid_mask(path); vox = {}
    for kz in range(-depth, depth + 1):
        mk = erode(m, max(0, abs(kz) - 1))
        for y, x in zip(*np.nonzero(mk)):
            vox[(x + offx - cx, -(y + offy - feet), kz + zoff)] = tuple(int(v) for v in rgb[y, x])
    return vox

knight = extrude(f'{BASE}/knight_frames_gun/Knight_Idle_1.png', 3)
gun = extrude(f'{BASE}/gun_sprite/Gun_1.png', 2, zoff=6, offx=11, offy=6, cx=16)
vox = {**knight, **gun}
print('voxels', len(knight), len(gun))

DIRS = [(1, 0, 0), (-1, 0, 0), (0, 1, 0), (0, -1, 0), (0, 0, 1), (0, 0, -1)]
def exposed(vox):
    F = []
    for p, col in vox.items():
        for n in DIRS:
            if (p[0] + n[0], p[1] + n[1], p[2] + n[2]) not in vox: F.append((p, n, col))
    return F
FACES = exposed(vox)

def corners(p, n):
    a = [i for i in range(3) if n[i]][0]; b, c = [i for i in range(3) if i != a]
    out = []
    for sb, sc in ((1, 1), (1, -1), (-1, -1), (-1, 1)):
        q = [p[0], p[1], p[2]]; q[a] += .5 * n[a]; q[b] += .5 * sb; q[c] += .5 * sc; out.append(q)
    return out

def render(theta, phi=math.radians(16), scale=16, size=(560, 640), origin=(280, 560), SS=3):
    img = Image.new('RGBA', (size[0] * SS, size[1] * SS), (0, 0, 0, 0)); d = ImageDraw.Draw(img)
    ct, st, cp, sp = math.cos(theta), math.sin(theta), math.cos(phi), math.sin(phi)
    L = np.array([-.45, .75, .5]); L /= np.linalg.norm(L)
    todo = []
    for p, n, col in FACES:
        nx = n[0] * ct + n[2] * st; nz = -n[0] * st + n[2] * ct; ny = n[1]
        if ny * sp + nz * cp <= 1e-6: continue
        px = p[0] * ct + p[2] * st; pz = -p[0] * st + p[2] * ct
        todo.append((p[1] * sp + pz * cp, p, n, col, (nx, ny * cp - nz * sp, ny * sp + nz * cp)))
    todo.sort(key=lambda t: t[0])
    for _, p, n, col, nv in todo:
        f = .5 + .62 * max(0, float(np.dot(nv, L)))
        c = np.clip(np.array(col) * f + np.array([22, 8, 56]) * max(0, 1 - f) * .6, 0, 255).astype(int)
        poly = []
        for q in corners(p, n):
            x = q[0] * ct + q[2] * st; z = -q[0] * st + q[2] * ct
            poly.append(((origin[0] + scale * x) * SS, (origin[1] - scale * (q[1] * cp - z * sp)) * SS))
        d.polygon(poly, fill=tuple(c) + (255,))
    return img.resize(size, Image.LANCZOS)

# ---- stills + turntable ----
for k, deg in (('front', 0), ('three_quarter', 32), ('side', 90)):
    render(math.radians(deg)).save(f'{SCENE}/model_3d/render_{k}.png')

def card(im, top=(41, 54, 111), bot=(239, 125, 87)):
    g = np.zeros((im.height, im.width, 3), np.uint8)
    for y in range(im.height): g[y] = [int(top[i] + (bot[i] - top[i]) * y / im.height) for i in range(3)]
    bg = Image.fromarray(g).convert('RGBA'); sh = Image.new('RGBA', im.size, (0, 0, 0, 0)); ImageDraw.Draw(sh).ellipse([130, 535, 430, 590], fill=(20, 10, 40, 110))
    bg.alpha_composite(sh); bg.alpha_composite(im); return bg.convert('RGB')

frames = [card(render(math.radians(a))).resize((420, 480), Image.LANCZOS) for a in range(0, 360, 10)]
frames[0].save(f'{SCENE}/model_3d/turntable.gif', save_all=True, append_images=frames[1:], duration=70, loop=0, optimize=True)

# hero shot composited on the valley background (320x180 -> 1280x720, integer x4)
bgim = Image.open(f'{SCENE}/background/background_full.png').resize((1280, 720), Image.NEAREST).convert('RGBA')
hero = render(math.radians(28), scale=13, size=(640, 700), origin=(320, 640))
fx, fy = 650, 668
sh = Image.new('RGBA', bgim.size, (0, 0, 0, 0)); ImageDraw.Draw(sh).ellipse([fx - 70, fy - 6, fx + 70, fy + 14], fill=(10, 8, 20, 150))
bgim.alpha_composite(sh); bgim.paste(hero, (fx - 320, fy - 640), hero); bgim.convert('RGB').save(f'{SCENE}/hero_render.png')

# ---- export real 3D files (GLB for GDevelop/Blender, OBJ+MTL fallback) ----
V, Fc, C = [], [], []
for p, n, col in FACES:
    base = len(V); V += corners(p, n)
    # keep counter-clockwise winding when viewed from outside
    q = [base, base + 1, base + 2, base + 3]
    a = np.array(V[base + 1]) - np.array(V[base]); b = np.array(V[base + 2]) - np.array(V[base + 1])
    if np.dot(np.cross(a, b), n) < 0: q = q[::-1]
    Fc += [[q[0], q[1], q[2]], [q[0], q[2], q[3]]]; C += [list(col) + [255]] * 4
mesh = trimesh.Trimesh(vertices=np.array(V, float) * .1, faces=np.array(Fc), vertex_colors=np.array(C, np.uint8), process=False)
mesh.export(f'{SCENE}/model_3d/knight.glb'); mesh.export(f'{SCENE}/model_3d/knight.ply')
print('faces', len(FACES), 'tris', len(Fc), 'glb ok')
