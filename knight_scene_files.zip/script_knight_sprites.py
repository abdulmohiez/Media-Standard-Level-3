import math, os, zipfile
import numpy as np
from PIL import Image, ImageDraw

W = H = 32
OUT = (17, 19, 24, 255)
C = dict(
    st_hi=(209, 216, 224, 255), st=(136, 149, 167, 255), st_sh=(75, 85, 99, 255),
    gold=(241, 196, 15, 255), cape=(168, 28, 55, 255), cape_d=(110, 16, 36, 255),
    blue=(47, 90, 168, 255), blue_d=(35, 63, 120, 255), leather=(90, 59, 36, 255),
    leg=(59, 74, 102, 255), leg_b=(42, 54, 77, 255), eye=(255, 70, 70, 255),
    blade=(232, 238, 244, 255),
)
T, SHN, UPPER, FORE, SWORD = 4.2, 4.2, 3.3, 3.0, 8.5
lerp = lambda a, b, t: a + (b - a) * t
mix = lambda a, b, t: {k: lerp(a[k], b[k], t) for k in a}
pt = lambda x, y, a, l: (x + math.sin(a) * l, y + math.cos(a) * l)

def render(p, gun=False, ox=0, rot=0, flash=0, arc=None):
    im = Image.new('RGBA', (W, H), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    cx = 16 + ox
    down = lambda h, k: T * math.cos(h) + SHN * math.cos(h - k)
    hy = 26 - max(down(p['hA'], p['kA']), down(p['hB'], p['kB'])) + p['bob']; hx = cx
    R = lambda x, y, a: (hx + x * math.cos(a) - y * math.sin(a), hy + x * math.sin(a) + y * math.cos(a))
    sh = R(.5, -5.5, p['lean']); neck = R(0, -6.6, p['lean'])
    hd = (neck[0] + math.sin(p['lean'] * .5 + p['tilt']) * 3 + .5, neck[1] - math.cos(p['lean'] * .5 + p['tilt']) * 3)
    line = lambda a, b, col, w=2: d.line([a, b], fill=col, width=w)

    def leg(h, k, thigh, shin):
        kn = pt(hx, hy, h, T); ft = pt(kn[0], kn[1], h - k, SHN)
        line((hx, hy), kn, thigh); line(kn, ft, shin)
        fx, fy = round(ft[0]), round(ft[1])
        d.rectangle([fx - 1, fy - 1, fx + 2, fy], fill=C['leather'])
    def arm(s1, e1, up):
        el = pt(sh[0], sh[1], s1, UPPER); hnd = pt(el[0], el[1], s1 + e1, FORE)
        line(sh, el, up); line(el, hnd, C['st']); d.point((round(hnd[0]), round(hnd[1])), fill=C['st_sh'])
        return hnd, s1 + e1

    sw = p['cape']
    d.polygon([(sh[0] - 1, sh[1]), (sh[0] + 1, sh[1] + 1), (hx - .5, hy + 3), (hx - 3 - sw, hy + 3.5), (sh[0] - 3 - sw * .5, sh[1] + 4)], fill=C['cape'])
    line((hx - 3 - sw, hy + 3.5), (hx - .5, hy + 3), C['cape_d'], 1)
    if gun:  # shield strapped to the back
        bx, by = R(-3.8, -3.2, p['lean'])
        d.polygon([(bx - 1.7, by - 2.6), (bx + 1.7, by - 2.6), (bx + 1.7, by + .8), (bx, by + 2.8), (bx - 1.7, by + .8)], fill=C['gold'])
        d.polygon([(bx - .8, by - 1.6), (bx + .8, by - 1.6), (bx + .8, by + .4), (bx, by + 1.6), (bx - .8, by + .4)], fill=C['blue'])
    leg(p['hB'], p['kB'], C['leg_b'], C['st_sh'])
    hnd, ang = arm(p['swS'], p['swE'], C['blue_d'])
    if gun:
        fx, fy = round(hnd[0]), round(hnd[1]); d.rectangle([fx - 1, fy - 1, fx, fy], fill=C['st_sh'])
    else:
        ba = ang + p['wr']; base = pt(hnd[0], hnd[1], ba, 1.5); tip = pt(hnd[0], hnd[1], ba, SWORD)
        line(pt(hnd[0], hnd[1], ba, -1.5), base, C['leather'], 1)
        line(base, tip, C['blade'], 1)
        line(pt(base[0], base[1], ba + math.pi / 2, 2), pt(base[0], base[1], ba - math.pi / 2, 2), C['gold'], 1)
    leg(p['hA'], p['kA'], C['leg'], C['st'])
    Lr = p['lean']
    d.polygon([R(-3, 0, Lr), R(3, 0, Lr), R(3.6, 2.6, Lr), R(0, 2, Lr), R(-3.6, 2.6, Lr)], fill=C['blue'])
    d.polygon([R(-3, -6.5, Lr), R(3, -6.5, Lr), R(3, -.5, Lr), R(-3, -.5, Lr)], fill=C['st'])
    line(R(-2.5, -6, Lr), R(-2.5, -1, Lr), C['st_hi'], 1)
    line(R(2.5, -6, Lr), R(2.5, -1, Lr), C['st_sh'], 1)
    line(R(-3, -1, Lr), R(3, -1, Lr), C['gold'], 1)
    d.ellipse([sh[0] - 1.6, sh[1] - 1.6, sh[0] + 1.6, sh[1] + 1.6], fill=C['st_hi'])
    hxr, hyr = hd; pl = p['plume']
    line((hxr - 1, hyr - 2.5), (hxr - 4 - pl, hyr - 2 + pl * .3), C['cape'], 1)
    line((hxr - 1, hyr - 1.5), (hxr - 3.5 - pl, hyr - 0.5 + pl * .3), C['cape_d'], 1)
    d.rounded_rectangle([hxr - 3, hyr - 3, hxr + 2.5, hyr + 3], radius=2, fill=C['st'])
    line((hxr - 2.5, hyr - 2), (hxr - 2.5, hyr + 2), C['st_hi'], 1)
    d.point((round(hxr), round(hyr) - 3), fill=C['gold'])
    line((hxr, hyr + .3), (hxr + 3, hyr + .3), OUT, 1)
    d.point((round(hxr + 1.5), round(hyr)), fill=C['eye'])
    sh_h, _ = arm(p['shS'], p['shE'], C['blue'])
    if not gun:  # shield in hand
        sx, sy = sh_h[0] + 1.2, sh_h[1] - .3
        d.polygon([(sx - 2.2, sy - 3), (sx + 2.2, sy - 3), (sx + 2.2, sy + 1), (sx, sy + 3.6), (sx - 2.2, sy + 1)], fill=C['gold'])
        d.polygon([(sx - 1.2, sy - 2), (sx + 1.2, sy - 2), (sx + 1.2, sy + .8), (sx, sy + 2.4), (sx - 1.2, sy + .8)], fill=C['blue'])
    a = np.array(im)[:, :, 3] > 0
    dil = a.copy(); dil[1:] |= a[:-1]; dil[:-1] |= a[1:]; dil[:, 1:] |= a[:, :-1]; dil[:, :-1] |= a[:, 1:]
    arr = np.array(im); arr[dil & ~a] = OUT; im = Image.fromarray(arr)
    if flash:
        arr = np.array(im).astype(float); m = (arr[:, :, 3] > 0) & ~np.all(arr[:, :, :3] == np.array(OUT[:3]), axis=2)
        arr[m, :3] = arr[m, :3] * .6 + np.array([255, 90, 90]) * .4; im = Image.fromarray(arr.astype('uint8'))
    if arc:
        a0, a1 = arc
        for i in range(15):
            t = lerp(a0, a1, i / 14); x, y = pt(sh[0], sh[1], t, 11)
            if 0 <= round(x) < W and 0 <= round(y) < H: im.putpixel((round(x), round(y)), (255, 255, 255, 230 if i > 5 else 120))
    if rot: im = im.rotate(rot, resample=Image.NEAREST, center=(cx, 27))
    return im

def build(gun):
    base_sh = (.15, .5) if gun else (.2, 1.1)
    def P(**k):
        b = dict(hA=.12, kA=.1, hB=-.1, kB=.1, lean=.03, swS=.25, swE=.5, wr=2.3, shS=base_sh[0], shE=base_sh[1], tilt=0, bob=0, cape=0, plume=0)
        b.update(k); return b
    IDLE = lambda b: P(lean=.03 + b * .01, swS=.25 + b * .04, shS=base_sh[0] + b * .03, bob=0.5 * (b > 0.3), plume=b * 1.0)
    HURT = P(lean=-.35, hA=.3, kA=.3, hB=-.3, kB=.3, swS=.1, swE=.3, shS=.4, shE=.4, tilt=-.4, cape=-1)
    DIE = P(lean=-.25, hA=.8, kA=1.5, hB=.1, kB=1.2, swS=1.0, swE=.3, shS=.8, shE=.3, tilt=-.5)
    RISE = P(lean=.05, hA=.9, kA=1.4, hB=-.2, kB=1.0, swS=2.2, swE=.3, shS=1.8, shE=.4, cape=-1)
    FALL = P(lean=0, hA=.35, kA=.3, hB=-.35, kB=.3, swS=1.6, swE=.2, shS=1.2, shE=.2, cape=2)
    def run(i, n=8):
        q = 2 * math.pi * i / n; s, c = math.sin(q), math.cos(q)
        return P(lean=.28, hA=s * .95, kA=max(0, c) * 1.5 + .2, hB=-s * .95, kB=max(0, -c) * 1.5 + .2,
                 swS=-s * .9 + .1, swE=1.4, shS=s * .4 + .1, shE=1.4, tilt=.05, cape=2.5, plume=2)
    r = lambda p, **k: render(p, gun=gun, **k)
    idle0 = IDLE(0); an = {}
    an['Idle'] = [r(IDLE(math.sin(2 * math.pi * i / 6))) for i in range(6)]
    an['Run'] = [r(run(i)) for i in range(8)]
    an['Jump'] = [r(mix(idle0, RISE, t)) for t in (.5, .85, 1.0)]
    an['Fall'] = [r(mix(RISE, FALL, .6)), r(FALL), r(mix(FALL, P(**{**FALL, 'swS': 1.9, 'shS': 1.0}), 1))]
    if gun:
        SHOOT = P(lean=-.12, hA=.2, kA=.15, hB=-.22, kB=.15, swS=.5, swE=.9, shS=.9, shE=.5, tilt=-.05, cape=-1.5, plume=-1)
        an['Shoot'] = [r(mix(idle0, SHOOT, .7)), r(SHOOT), r(mix(SHOOT, idle0, .5))]
    else:
        WIND = P(lean=-.12, hA=.1, hB=-.3, kB=.2, swS=2.5, swE=.4, wr=1.0, shS=.3, shE=1.2, tilt=-.1)
        SLASH = P(lean=.3, hA=.6, kA=.5, hB=-.5, kB=.2, swS=.6, swE=.2, wr=.9, shS=.1, shE=1.0, tilt=.1, cape=1.5)
        BLOCK = P(lean=.1, hA=.4, kA=.8, hB=-.4, kB=.6, swS=-.4, swE=1.0, shS=1.4, shE=.3)
        an['Attack'] = [r(mix(idle0, WIND, .5)), r(WIND), r(mix(WIND, SLASH, .6), ox=1, arc=(3.0, 2.0)),
                        r(SLASH, ox=1, arc=(3.0, .9)), r(mix(SLASH, idle0, .5), ox=1), r(idle0)]
        an['Block'] = [r(mix(idle0, BLOCK, .6)), r(BLOCK)]
    an['Hurt'] = [r(HURT, flash=1), r(mix(HURT, idle0, .3))]
    an['Death'] = [r(HURT, flash=1), r(mix(HURT, DIE, .5), ox=1), r(DIE, ox=3, rot=8), r(DIE, ox=5, rot=35), r(DIE, ox=6, rot=65), r(DIE, ox=6, rot=88)]
    return an

def save(an, folder, preview):
    out = f'/mnt/user-data/outputs/{folder}'; os.makedirs(out, exist_ok=True)
    for name, fr in an.items():
        for i, f in enumerate(fr, 1): f.save(f'{out}/Knight_{name}_{i}.png')
        strip = Image.new('RGBA', (W * len(fr), H), (0, 0, 0, 0))
        for i, f in enumerate(fr): strip.paste(f, (i * W, 0))
        strip.save(f'{out}/sheet_{name}.png')
    Z = 6; rows = list(an.items()); mw = max(len(f) for _, f in rows)
    prev = Image.new('RGBA', (mw * W * Z, len(rows) * H * Z), (156, 203, 232, 255))
    for rr, (name, fr) in enumerate(rows):
        for i, f in enumerate(fr): prev.alpha_composite(f.resize((W * Z, H * Z), Image.NEAREST), (i * W * Z, rr * H * Z))
    prev.convert('RGB').save(f'/mnt/user-data/outputs/{preview}')

save(build(False), 'knight_frames', 'knight_preview.png')
save(build(True), 'knight_frames_gun', 'knight_preview_gun.png')
