"""Dawn valley parallax background - built with standard game-art / procedural-generation techniques.
Every technique is listed in STANDARDS.md. Internal resolution 320x180 (16:9, integer-scales to 720p/1080p/4K)."""
import math, os
import numpy as np
from PIL import Image, ImageDraw

W, H = 320, 180
OUT = '/mnt/user-data/outputs/background_valley'

# ---- STANDARD: fixed public pixel-art palette (Sweetie 16 by GrafxKid) ----
HEX = ['1a1c2c', '5d275d', 'b13e53', 'ef7d57', 'ffcd75', 'a7f070', '38b764', '257179',
       '29366f', '3b5dc9', '41a6f6', '73eff7', 'f4f4f4', '94b0c2', '566c86', '333c57']
PAL = np.array([[int(h[i:i + 2], 16) for i in (0, 2, 4)] for h in HEX], float) / 255

# ---- STANDARD: sRGB <-> linear transfer functions (IEC 61966-2-1); all blending is done in linear light ----
def s2l(c):
    c = np.clip(np.asarray(c, float), 0, 1); return np.where(c <= .04045, c / 12.92, ((c + .055) / 1.055) ** 2.4)
def l2s(c):
    c = np.clip(c, 0, 1); return np.where(c <= .0031308, c * 12.92, 1.055 * c ** (1 / 2.4) - .055)
col = lambda h: s2l(np.array([int(h[i:i + 2], 16) for i in (0, 2, 4)]) / 255)
mix = lambda a, b, t: a + (b - a) * t

# ---- STANDARD: 8x8 Bayer ordered-dither matrix (Bayer, 1973) ----
def bayer(n):
    m = np.array([[0, 2], [3, 1]])
    while m.shape[0] < n: m = np.block([[4 * m, 4 * m + 2], [4 * m + 3, 4 * m + 1]])
    return (m + .5) / m.size
B8 = np.tile(bayer(8), (H // 8 + 1, W // 8 + 1))[:H, :W]

# ---- STANDARD: Perlin gradient noise (improved quintic fade) on a periodic lattice => seamless horizontal tiling ----
def pnoise(x, period, seed):
    g = np.random.RandomState(seed).uniform(-1, 1, period)
    xi = np.floor(x).astype(int); xf = x - xi; u = xf ** 3 * (xf * (xf * 6 - 15) + 10)
    a = g[xi % period] * xf; b = g[(xi + 1) % period] * (xf - 1); return 2 * (a + (b - a) * u)

# ---- STANDARD: fractional Brownian motion (fBm) and ridged multifractal (Musgrave) ----
def fbm(x, y=0., base=3, octaves=5, gain=.5, lac=2, seed=1, ridged=False, ystretch=0.):
    tot = norm = 0; amp = 1
    for o in range(octaves):
        P = base * lac ** o; n = pnoise((x + y * ystretch) / W * P, P, seed + o)
        if ridged: n = (1 - np.abs(n)) ** 2
        tot = tot + amp * n; norm += amp; amp *= gain
    return tot / norm

xs = np.arange(W)[None, :].astype(float); ys = np.arange(H)[:, None].astype(float)

class Layer:
    def __init__(s): s.rgb = np.zeros((H, W, 3)); s.a = np.zeros((H, W), bool)
    def put(s, mask, color):
        s.rgb[mask] = color[mask] if getattr(color, 'ndim', 1) == 3 else color; s.a |= mask

# ---- STANDARD: exponential (Beer-Lambert) atmospheric perspective: f = 1 - exp(-k*d) ----
FOG = col('c2b4cc')   # warm-lavender dawn haze
fog_amt = lambda d, k=1.5: 1 - math.exp(-k * d)

SUN = np.array([.6, -.8])  # ONE consistent key-light direction (from upper right) for the whole scene

# ---- Layer 0: sky with sun, glow and stratus clouds ----
def sky():
    stops = [(0, '29366f'), (.32, '3b5dc9'), (.58, '41a6f6'), (.80, 'ffcd75'), (1.0, 'ef7d57')]
    t = np.clip(ys / (H * .72), 0, 1) * np.ones((1, W)); out = np.zeros((H, W, 3))
    for (t0, c0), (t1, c1) in zip(stops[:-1], stops[1:]):
        m = (t >= t0) & (t <= t1); f = ((t - t0) / (t1 - t0))[..., None]; out = np.where(m[..., None], s2l(mix(l2s(col(c0)), l2s(col(c1)), f)), out)
    sx, sy = 226, 74; d = np.hypot(xs - sx, ys - sy)
    out = out + np.exp(-d / 46)[..., None] * np.array([.9, .5, .2]) * .55
    out = np.where((d < 10)[..., None], col('fff2c0'), out); out = np.where(((d < 12) & (d >= 10))[..., None], col('ffcd75'), out)
    img = out.copy()
    rng = np.random.RandomState(3)
    for bx, by in ((60, 40), (95, 30), (270, 52)):  # birds
        for k, (dx, dy) in enumerate(((0, 0), (1, 1), (2, 0), (3, 1), (4, 0))): img[by + dy, bx + dx] = col('333c57')
    return img

# ---- Mountain layers: ridged fBm height field + Lambert (N.L) lighting from the ridge slope + snow line ----
def mountain(y0, amp, seed, depth, shadow, lit, ridged=True, snow=False, base=2, k=1.5):
    L = Layer()
    h = fbm(xs[0], base=base, seed=seed, ridged=ridged, octaves=5)
    if not ridged: h = (h + 1) / 2
    env = (fbm(xs[0], base=1, seed=seed + 9, octaves=2) + 1) / 2
    surf = y0 - amp * (.30 + .70 * np.clip(h, 0, 1)) * (.55 + .45 * env)
    mask = ys >= surf[None, :]
    slope = np.gradient(surf); lam = np.clip((slope * SUN[0] - SUN[1]) / np.sqrt(slope ** 2 + 1), 0, 1)  # N.L with N=(s',-1)
    d = ys - surf[None, :]
    tex = (fbm(xs, ys, base=6, seed=seed + 3, octaves=4, ystretch=.55) + 1) / 2   # gullies / strata
    s = np.clip(.04 + 1.05 * lam[None, :] ** .8 * (.5 + .7 * tex), 0, 1) * (1 - .45 * np.clip(d / (amp * 1.1), 0, 1))
    c = mix(shadow, lit, s[..., None])
    if snow:
        elev = (y0 - surf) / amp; depth_px = np.clip((elev - .50) * 55, 0, None)[None, :] * (.55 + .9 * tex)
        sm = mask & (d < depth_px)
        sc = mix(col('94b0c2'), col('f4f4f4'), np.clip(.25 + lam[None, :] * 1.1, 0, 1)[..., None] * np.ones((H, W, 1)))
        c = np.where(sm[..., None], sc, c)
    f = np.clip(fog_amt(depth, k) + .18 * np.clip((ys - y0) / max(1, H - y0), 0, 1), 0, 1)
    c = mix(c, FOG, f[..., None]) if f.ndim == 2 else mix(c, FOG, f)
    L.put(mask, c); return L, surf

# ---- STANDARD: Poisson-disc style (min-distance dart-throwing) sampling for natural tree placement ----
def poisson_x(n, rmin, seed):
    rng = np.random.RandomState(seed); pts = []
    for _ in range(4000):
        p = rng.uniform(0, W)
        if all(min(abs(p - q), W - abs(p - q)) >= rmin for q in pts): pts.append(p)
        if len(pts) >= n: break
    return pts

def pine(L, cx, base_y, h, hw, shadow, lit, fog=0., fogc=None, dark_trunk=None):
    tiers = max(3, int(h / 7)); step = h * .78 / tiers
    for off in (-W, 0, W):
        for k in range(tiers):
            ya = base_y - h + k * step; yb = ya + step * 1.8; wk = hw * (.35 + .65 * (k + 1) / tiers)
            m = Image.new('L', (W, H), 0); ImageDraw.Draw(m).polygon([(cx + off, ya), (cx + off - wk, yb), (cx + off + wk, yb)], fill=255)
            mk = np.array(m) > 0
            if not mk.any(): continue
            yy, xx = np.nonzero(mk); s = np.clip(.3 + .7 * ((xx - (cx + off)) / (2 * wk) + .5), 0, 1) * (1 - .25 * ((yy - ya) / (yb - ya)) ** 2)
            c = mix(shadow, lit, s[:, None])
            if fog: c = mix(c, fogc, fog)
            L.rgb[yy, xx] = c; L.a[yy, xx] = True
    tc = col('333c57') if dark_trunk is None else dark_trunk
    for off in (-W, 0, W):
        x = int(cx + off)
        if 0 <= x < W - 1: L.rgb[int(base_y - step * .5):int(base_y), x:x + 2] = tc; L.a[int(base_y - step * .5):int(base_y), x:x + 2] = True

def rect(L, x0, y0, x1, y1, lit_edge=True, base=.42, shadow=None, lit=None, fog=.12):
    for y in range(int(y0), int(y1)):
        for x in range(int(x0), int(x1)):
            if not (0 <= x < W and 0 <= y < H): continue
            s = base + (.5 if (lit_edge and x >= x1 - 2) else 0) + (.3 if y == int(y0) else 0) - .15 * ((y - y0) / max(1, y1 - y0))
            c = mix(shadow, lit, np.clip(s, 0, 1)); L.rgb[y, x] = mix(c, FOG, fog); L.a[y, x] = True

# ---- Layer 3: forested foothills, ruined fortress (rule-of-thirds focal point), pines ----
def foothills():
    L = Layer(); rng = np.random.RandomState(5)
    h = (fbm(xs[0], base=3, seed=21, octaves=4) + 1) / 2
    bump = 15 * np.exp(-((xs[0] - 104) / 20) ** 2)         # rocky outcrop under the ruins
    surf = 154 - 20 * h - bump
    mask = ys >= surf[None, :]
    slope = np.gradient(surf); lam = np.clip((slope * SUN[0] - SUN[1]) / np.sqrt(slope ** 2 + 1), 0, 1)
    s = np.clip(.2 + .8 * lam[None, :], 0, 1) * (1 - .4 * np.clip((ys - surf[None, :]) / 40, 0, 1))
    c = mix(col('0a1a2a'), col('1a4258'), s[..., None]); f = fog_amt(.2, 1.0) + .15 * np.clip((ys - 150) / 30, 0, 1)
    L.put(mask, mix(c, FOG, np.clip(f, 0, 1)[..., None]))
    stone_s, stone_l = col('1b2450'), col('8e9fd0')
    base_y = int(surf[104]) + 3
    rect(L, 90, base_y - 44, 106, base_y, shadow=stone_s, lit=stone_l)           # keep
    for x in range(90, 106):                                                    # broken top
        cut = rng.randint(0, 9) if x % 3 else rng.randint(3, 12)
        L.a[base_y - 44:base_y - 44 + cut, x] = False
    rect(L, 106, base_y - 22, 134, base_y, shadow=stone_s, lit=stone_l)          # curtain wall
    for x in range(106, 134):
        if (x // 4) % 2 == 0: L.a[base_y - 24:base_y - 22, x] = True; L.rgb[base_y - 24:base_y - 22, x] = mix(mix(stone_s, stone_l, .7), FOG, .12)
        if rng.rand() > .75: L.a[base_y - 22:base_y - 22 + rng.randint(2, 7), x] = False
    rect(L, 76, base_y - 30, 89, base_y, shadow=stone_s, lit=stone_l)           # side tower
    for i in range(8):                                                          # half-collapsed conical roof
        w = 8 - i; L.rgb[base_y - 31 - i, 76 + i // 2 + 2:76 + 2 + max(1, w // 2) + 4] = mix(col('566c86'), FOG, .12); L.a[base_y - 31 - i, 76 + i // 2 + 2:76 + 2 + max(1, w // 2) + 4] = True
    for cx_ in (121,):                                                          # arch opening
        for y in range(base_y - 12, base_y):
            for x in range(cx_ - 5, cx_ + 6):
                if (x - cx_) ** 2 + max(0, (base_y - 7) - y) ** 2 * 1.0 < 26 + (y >= base_y - 7) * 80: L.a[y, x] = False
    for wx, wy in ((97, base_y - 32), (97, base_y - 20), (82, base_y - 18), (127, base_y - 11)):   # lit windows (warm accent colour)
        L.rgb[wy:wy + 3, wx:wx + 2] = col('ffcd75'); L.a[wy:wy + 3, wx:wx + 2] = True
    xs_t = poisson_x(46, 6.5, 8)
    for px in sorted(xs_t, key=lambda v: surf[int(v) % W]):
        sy = surf[int(px) % W] + 3
        if 84 < px < 140: continue
        pine(L, px, sy, rng.randint(12, 24), rng.randint(4, 6), col('0d2a36'), col('34a16c'), fog=.18, fogc=FOG)
    return L

# ---- Layer 4: height-fog mist, dithered so it stays in-palette ----
def mist():
    L = Layer(); d = np.zeros((H, W))
    for yc, sp, sd in ((142, 7, 51), (160, 8, 52)):
        n = (fbm(xs, ys, base=5, seed=sd, octaves=3, ystretch=.2) + 1) / 2
        d = np.maximum(d, np.exp(-((ys - yc) / sp) ** 2) * (.25 + .6 * n))
    m = d > (B8 * .9 + .34); L.put(m, col('94b0c2')); return L

# ---- Layer 5: foreground silhouette (dark value, rim-lit from the key light) ----
def foreground():
    L = Layer(); rng = np.random.RandomState(9)
    h = (fbm(xs[0], base=4, seed=31, octaves=3) + 1) / 2; surf = 168 - 7 * h
    L.put(ys >= surf[None, :], col('1a1c2c'))
    rim = (ys >= surf[None, :]) & (ys < surf[None, :] + 2); L.rgb[rim] = col('257179')
    for x in range(W):
        if rng.rand() > .55:
            g = rng.randint(2, 6); y1 = int(surf[x]); L.rgb[y1 - g:y1, x] = col('1a1c2c'); L.a[y1 - g:y1, x] = True
            if rng.rand() > .7: L.rgb[y1 - g:y1 - g + 1, x] = col('257179')
    for cx, hh, hw in ((14, 96, 14), (298, 110, 16), (44, 62, 10), (272, 58, 9), (162, 40, 8)):
        pine(L, cx, 172, hh, hw, col('1a1c2c'), col('257179'), dark_trunk=col('1a1c2c'))
    return L

# ---- STANDARD: CIE 1976 L*a*b* (D65) perceptual colour distance for palette matching ----
def srgb2lab(c):
    l = s2l(c); M = np.array([[.4124564, .3575761, .1804375], [.2126729, .7151522, .0721750], [.0193339, .1191920, .9503041]])
    xyz = l @ M.T / np.array([.95047, 1.0, 1.08883]); f = np.where(xyz > .008856, np.cbrt(xyz), 7.787 * xyz + 16 / 116)
    return np.stack([116 * f[..., 1] - 16, 500 * (f[..., 0] - f[..., 1]), 200 * (f[..., 1] - f[..., 2])], -1)
PAL_LAB = srgb2lab(PAL)

# ---- quantise to the fixed palette with 8x8 ordered dithering ----
def quantise(rgb_lin, spread=.10):
    srgb = np.clip(l2s(rgb_lin) + (B8[..., None] - .5) * spread, 0, 1)
    d = ((srgb2lab(srgb)[:, :, None, :] - PAL_LAB[None, None]) ** 2).sum(-1)
    return (PAL[d.argmin(-1)] * 255).astype(np.uint8)

def to_img(L, opaque=False):
    rgb = quantise(L.rgb); a = np.full((H, W), 255, np.uint8) if opaque else (L.a * 255).astype(np.uint8)
    return Image.fromarray(np.dstack([rgb, a]), 'RGBA')

sk = Layer(); sk.rgb = sky(); sk.a[:] = True
far, _ = mountain(138, 80, 11, .6, col('2b3c8a'), col('9fb4e0'), True, True, 2, 1.0)
mid, _ = mountain(146, 44, 17, .4, col('10163c'), col('4a6cb4'), True, False, 3, 1.0)
layers = {'0_sky': to_img(sk, True), '1_mountains_far': to_img(far), '2_mountains_mid': to_img(mid),
          '3_foothills_ruins': to_img(foothills()), '4_mist': to_img(mist()), '5_foreground': to_img(foreground())}
full = layers['0_sky'].copy()
for k in list(layers)[1:]: full.alpha_composite(layers[k])
os.makedirs(OUT, exist_ok=True)
for k, im in layers.items(): im.save(f'{OUT}/layer_{k}.png')
full.save(f'{OUT}/background_full.png')
full.resize((W * 4, H * 4), Image.NEAREST).convert('RGB').save('/mnt/user-data/outputs/background_valley_preview.png')   # integer 4x scale = 1280x720
print('ok')
