All files are in this one folder.
- hero_render_knight_in_valley.png : 3D knight standing in the valley (1280x720)
- background_full.png + background_layer_*.png : the dawn-valley background and its 6 separate layers (320x180)
- background_STANDARDS.md : the industry standards used for the background
- model_knight.glb / model_knight.ply : the 3D knight model
- model_render_*.png, model_turntable.gif : renders of the 3D model
- script_*.py : the scripts that generated everything
AI assistance was used to make these assets - declare it in your NCEA documentation.
